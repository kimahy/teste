package spring.mvc.benkfit.service;

import org.springframework.stereotype.*;

@Service
public class ServiceImpl_syk {

}
