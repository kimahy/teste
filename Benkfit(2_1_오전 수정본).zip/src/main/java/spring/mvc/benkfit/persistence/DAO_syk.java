package spring.mvc.benkfit.persistence;

public interface DAO_syk {

}
